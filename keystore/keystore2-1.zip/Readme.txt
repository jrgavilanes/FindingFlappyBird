HOW TO USE
----------------

**BEFORE USE**

1) RIGHT-CLICK on keystore.exe and run as administrator
2) WRITE DOWN all the information and save what you put in the boxes. It is important information.
3) ALWAYS save to c:\filename.keystore --- Once it has been generated you can move this file to any folder you like.

**BEFORE USE**


HOW TO GENERATE A KEYSTORE FILE
--------------------------------------------
Run keystore.exe as administrator

1) Click Browse and locate your JDK folder, you need to locate where keytool.exe is installed.
	It is usually (c:\program files\java\jdk~\bin\) or (c:\program files(x86)\java\jdk~\bin)

2) Click Browse and choose a folder then type a filename to save your keystore file.

3) Fill in ALL the boxes (make them unique and remember no spaces inside ALIAS and less than 8 letters)

4) Click Build, it should build. After it's finished building, head to the directory you chose to save the file and the .keystore file should be in there.

5) All done. Once your keystore file has been generated you use this to sign your games. This file can be moved to any folder once it's been generated.